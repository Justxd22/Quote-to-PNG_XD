from gquote.__main__ import gquote
